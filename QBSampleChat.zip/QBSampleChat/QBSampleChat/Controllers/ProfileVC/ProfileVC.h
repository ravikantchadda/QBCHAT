//
//  ProfileVC.h
//  QBSampleChat
//
//  Created by ravi kant on 9/22/15.
//  Copyright © 2015 Net Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileVC : UITableViewController

@end
