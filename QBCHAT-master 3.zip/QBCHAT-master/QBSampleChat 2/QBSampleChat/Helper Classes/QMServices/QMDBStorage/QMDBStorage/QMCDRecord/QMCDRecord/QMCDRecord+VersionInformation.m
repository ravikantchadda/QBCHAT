//
//  Created by Tony Arnold on 8/04/2014.
//  Copyright (c) 2014 QMCD Panda Software LLC. All rights reserved.
//

#import "QMCDRecord+VersionInformation.h"

@implementation QMCDRecord (VersionInformation)

+ (QMCDRecordVersionNumber)version
{
    return QMCDRecordVersionNumber3_0;
}

@end
