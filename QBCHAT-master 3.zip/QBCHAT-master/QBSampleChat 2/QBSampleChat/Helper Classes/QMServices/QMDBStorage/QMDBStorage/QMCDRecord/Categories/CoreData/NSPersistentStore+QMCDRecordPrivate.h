//
//  Created by Tony Arnold on 28/04/2014.
//  Copyright (c) 2014 QMCD Panda Software LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

NSString *QM_defaultApplicationStorePath(void);
NSString *QM_userDocumentsPath(void);
