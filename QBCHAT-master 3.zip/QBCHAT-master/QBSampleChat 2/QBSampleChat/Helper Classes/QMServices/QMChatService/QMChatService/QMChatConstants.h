//
//  QMChatConstants.h
//  QMServices
//
//  Created by Injoit on 7/6/15.
//  Copyright (c) 2015 Quickblox Team. All rights reserved.
//

#define kQMChatMessagesPerPage 100
