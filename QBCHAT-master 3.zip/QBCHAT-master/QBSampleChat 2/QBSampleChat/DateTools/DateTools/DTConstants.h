// Copyright (C) 2014 by Matthew York
//
// Permission is hereby granted, free of charge, to any
// person obtaining a copy of this software and
// associated documentation files (the "Software"), to
// deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge,
// publish, distribute, sublicense, and/or sell copies of the
// Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall
// be included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
// BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
// ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#import <Foundation/Foundation.h>

static const long long SECONDS_IN_YEAR = 31556900;
static const NSInteger SECONDS_IN_MONTH_28 = 2419200;
static const NSInteger SECONDS_IN_MONTH_29 = 2505600;
static const NSInteger SECONDS_IN_MONTH_30 = 2592000;
static const NSInteger SECONDS_IN_MONTH_31 = 2678400;
static const NSInteger SECONDS_IN_WEEK = 604800;
static const NSInteger SECONDS_IN_DAY = 86400;
static const NSInteger SECONDS_IN_HOUR = 3600;
static const NSInteger SECONDS_IN_MINUTE = 60;
static const NSInteger MILLISECONDS_IN_DAY = 86400000;
#import "DTError.h"